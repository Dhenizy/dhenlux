package com.dhenlux.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

public class ClockAlarms {
    private static final String PREF = "dhenlux_clock";
    private static final String KEY = "done";


    // Puts Dhenlux's chime into the phone's Alarms sound library (Android 10+), so the
    // Clock app can ring the exact same sound as Dhenlux's own alarm. Needs no permission.
    private static Uri ringtone(Context ctx, String sound) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) {
                return null;
            }
            Uri coll = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            String raw = AlarmReceiver.rawName(sound);
            String name = "dhenlux_" + raw + ".wav";
            String title = "bells".equals(sound) ? "Dhenlux Golden Bells" : ("neon".equals(sound) ? "Dhenlux Neon Pulse" : "Dhenlux Marimba Hustle");
            Cursor c = ctx.getContentResolver().query(coll, new String[] {MediaStore.Audio.Media._ID},
                MediaStore.Audio.Media.DISPLAY_NAME + "=?", new String[] {name}, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        return ContentUris.withAppendedId(coll, c.getLong(0));
                    }
                } finally {
                    c.close();
                }
            }
            ContentValues v = new ContentValues();
            v.put(MediaStore.Audio.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Audio.Media.TITLE, title);
            v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/x-wav");
            v.put(MediaStore.Audio.Media.RELATIVE_PATH, android.os.Environment.DIRECTORY_ALARMS);
            v.put(MediaStore.Audio.Media.IS_ALARM, 1);
            v.put(MediaStore.Audio.Media.IS_MUSIC, 0);
            Uri u = ctx.getContentResolver().insert(coll, v);
            if (u == null) {
                return null;
            }
            int rid = ctx.getResources().getIdentifier(raw, "raw", ctx.getPackageName());
            AssetFileDescriptor afd = ctx.getResources().openRawResourceFd(rid);
            java.io.InputStream in = afd.createInputStream();
            java.io.OutputStream out = ctx.getContentResolver().openOutputStream(u);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            out.close();
            in.close();
            return u;
        } catch (Exception e) {
            return null;
        }
    }

    public static int apply(Activity act, JSONArray alarms) throws Exception {
        SharedPreferences sp = act.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String done = sp.getString(KEY, "");
        long now = System.currentTimeMillis();
        int made = 0;
        StringBuilder keep = new StringBuilder();
        for (int i = 0; i < alarms.length() && made < 8; i++) {
            JSONObject o = alarms.getJSONObject(i);
            long at = o.getLong("at");
            if (at < now + 5000 || at > now + 86400000L) {
                continue;
            }
            String tag = o.getInt("id") + "_" + at + ";";
            if (done.contains(tag)) {
                continue;
            }
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.setTimeInMillis(at);
            Uri chime = ringtone(act, o.optString("sound", "marimba"));
            Intent it = new Intent(AlarmClock.ACTION_SET_ALARM);
            it.putExtra(AlarmClock.EXTRA_HOUR, c.get(java.util.Calendar.HOUR_OF_DAY));
            it.putExtra(AlarmClock.EXTRA_MINUTES, c.get(java.util.Calendar.MINUTE));
            it.putExtra(AlarmClock.EXTRA_MESSAGE, o.optString("message", "Dhenlux pickup"));
            it.putExtra(AlarmClock.EXTRA_VIBRATE, true);
            if (chime != null) {
                it.putExtra(AlarmClock.EXTRA_RINGTONE, chime.toString());
            }
            it.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(it);
            keep.append(tag);
            made++;
        }
        String[] old = done.split(";");
        for (String t : old) {
            int u = t.indexOf('_');
            if (u > 0) {
                try {
                    long at = Long.parseLong(t.substring(u + 1));
                    if (at > now) {
                        keep.append(t).append(";");
                    }
                } catch (Exception ignored) {
                }
            }
        }
        sp.edit().putString(KEY, keep.toString()).apply();
        return made;
    }
}
